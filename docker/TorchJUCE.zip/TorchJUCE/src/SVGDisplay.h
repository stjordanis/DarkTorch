#pragma once

#include "JuceHeader.h"
#include "../include/utils/vision_utils.hpp"

auto VU= VisionUtils();        

class InvalidImageLabel : public Label
{
public:
    InvalidImageLabel()
    {
        setText("Invalid Image", dontSendNotification);
        setJustificationType(Justification::centred);
    }
};

class SVGDisplayer : public Component
{
public:
    explicit SVGDisplayer(const File& fileToLoad)
    {
        image = Drawable::createFromImageFile(fileToLoad);

        if (image != nullptr)
            addAndMakeVisible(*image);
        else
            addAndMakeVisible(invalidImageLabel);
    }

    void resized() override
    {
        if (image != nullptr)
            image->setBounds(getLocalBounds());
        else
            invalidImageLabel.setBounds(getLocalBounds());
    }

    InvalidImageLabel invalidImageLabel;
    std::unique_ptr<Drawable> image;
};

class OpenCVDisplayer : public Component
{
public:
    explicit OpenCVDisplayer(const juce::Image& image)
    {   
        // auto juceImage=VU.toJUCEImage(frame,kIMAGE_SIZE_TORCH, kIMAGE_SIZE_TORCH, kCHANNELS);    
        // image = Drawable::createFromImageFile(fileToLoad);
        if (image != nullptr)
            addAndMakeVisible(*image);
        else
            addAndMakeVisible(invalidImageLabel);
    }

    void resized() override
    {
        if (image != nullptr)
            image->setBounds(getLocalBounds());
        else
            invalidImageLabel.setBounds(getLocalBounds());
    }

    InvalidImageLabel invalidImageLabel;
    juce::Image image;    
};