#include <torch/script.h> // One-stop header.
#include <iostream>
#include <vector>
#include <memory>
#include <cmath>
#include <iostream>
#include <chrono>
#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <ostream>
// #include "../include/lane/net_utils.hpp"
// #include "../include/lane/viz_utils.hpp"

#include "../include/tqdm/tqdm.h"
#define kIMAGE_SIZE 512
#define kIMAGE_SIZE_TORCH 512
#define kCHANNELS 3
#define kCHANNELS_GRAY 1


// Could be done also with blending but I'm lazy
// Color the image pixel according to the prediction

int main(int argc, char **argv) {
    
    

    // Loading your model
    const std::string s_model_name = argv[1];
    std::cout << "Loading " << s_model_name << std::endl;
    auto module = torch::jit::load(s_model_name, torch::kCUDA);
//    module->to(at::kCUDA);
    assert(module != nullptr);

    const std::string s_image_name0 = argv[2];
    std::cout << " >>> Loading " << s_image_name0 << std::endl;

    time_t start, end;
    long num_frames = 0;
    time(&start);
    cv::VideoCapture video_reader(s_image_name0);    

    if (!video_reader.isOpened())
    {
        std::cout << "!!! Failed to open file: " << s_image_name0 << std::endl;
        return -1;
    }

    long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
    long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
    long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
    cv::VideoWriter videoWriter;

    std::cout << "WIDTH " << frame_w << "\n";
    std::cout << "HEIGHT " << frame_h << "\n";
    std::cout << "nb_frames " << nb_frames << "\n";

    double avgFPS = 1.0;
    cv::Mat frame;    
    tqdm bar;
    bar.reset();
//    bar.set_theme_basic();
    bar.set_theme_circle();    

    // Iterate over images
    // for(int i = 0; i < dl.getNumImages(); i++){
    for (num_frames = 0; num_frames < nb_frames; num_frames++) {  
      // cv::Mat frame;

      // Pytorch requires to submit to the network a vector of inputs of this type. Only framework stuff
      // std::vector<torch::jit::IValue> inputs;
    
      // The network is trained with 512x256 images, better use this size
      // cv::resize(dl.getNextImage(), frame, cv::Size(512, 256));      

      // Convert to Tensor using the helper class
      // Saves everything in a tensor, swaps some dimensions because opencv saves images in WxHxC format, we need CxHxW.
      // Again, framework stuff. Finally, it divides everything by 255 to get a 0-1 float32 matrix.
      // at::Tensor image_tensor = tc.toTensor(image); 

      video_reader.read(frame);        
      // video_reader >> frame;
      cv::cvtColor(frame, frame, CV_BGR2RGB);        
      //#frame = cv2.resize(frame, (224, 224));
      frame.convertTo(frame, CV_32FC3, 1.0f / 255.0f);        
      cv::resize(frame, frame, cv::Size(512, 256));
      
      auto input_tensor = torch::from_blob(frame.data, {1, 512, 256, 3});      
      input_tensor = input_tensor.permute({0, 3, 1, 2});
      input_tensor = input_tensor.to(at::kCUDA);   
      // std::cout << "input_tensor:" << input_tensor << "\n";     
      
      // Push back the input image
      // inputs.push_back(input_tensor);

      // Inference phase
      // at::Tensor output = module.forward(inputs).toTensor();
      torch::Tensor out_tensor = module.forward({input_tensor}).toTensor(); // //Predictions array of 5 images 3 by 512 by 256  
      const auto dimensions = out_tensor.ndimension();         

      // Extracting the prediction: we have a quantity that is directly proportional to probability.
      // // To extract the most probable class, we take the argmax of that quantity.
      std::tuple<torch::Tensor, torch::Tensor> output_max = torch::max(out_tensor, 1);
      torch::Tensor argmax = std::get<1>(output_max);   //single channel image 1 by 512 by 256  

      argmax = argmax.unsqueeze(-1); // strange stuff !!! 
      argmax = argmax.view({1, 1, 512,256}); // strange stuff !!! 

      // argmax = argmax.to(at::kByte);      
    //   std::cout << "dimensions:" << argmax.ndimension() << "\n";
    //   std::cout << "v_size 0:" << argmax.size(0) << "\n";
    //   std::cout << "v_size 1:" << argmax.size(1) << "\n";
    //   std::cout << "v_size 2:" << argmax.size(2) << "\n";
    //   std::cout << "v_size 3:" << argmax.size(3) << "\n";
      // std::cout << "output_max:" << argmax << "\n"; // we need 1 *3 * 512 * 512 
      
      // cv::Mat resultImg;
      // resultImg=cv::Mat(512, 256, CV_8UC1, argmax.data_ptr());
      cv::Mat resultImg(512, 256, CV_8UC1);
      
      argmax = argmax.squeeze().detach();
      argmax = argmax.mul(255).clamp(0, 255).to(torch::kU8);
      argmax = argmax.to(torch::kCPU);      
      std::memcpy((void *) resultImg.data, argmax.data_ptr(), sizeof(torch::kU8) * argmax.numel());
      

      cv::imshow("window", resultImg);
      char key = cv::waitKey(10);
      if (key == 27) // ESC
          break;

      bar.progress(num_frames, nb_frames);

    }

    bar.finish();
    time(&end);
    // Time elapsed
    double seconds = difftime(end, start);
    std::cout << "Time taken : " << seconds << " seconds" << std::endl;
    // Calculate frames per second
    double fps = num_frames / seconds;
    std::cout << "Estimated frames per second : " << fps << std::endl;

    return 0;
  
}
