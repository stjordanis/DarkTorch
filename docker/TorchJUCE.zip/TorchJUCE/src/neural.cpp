//#include <torch/torch.h>
#include <torch/script.h> // One-stop header.

#include <iostream>
#include <vector>
#include <memory>
#include <cmath>

#include <iostream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <typeinfo>
//#include <include/neural.h>
#include <thread>
#include <future>
#include "../include/utils/vision_utils.hpp"


using namespace std;
//using namespace cv;
using namespace std::chrono;

#define kIMAGE_SIZE 512
#define kCHANNELS 3
#define kTOP_K 3

//temporarily disable gradient recording
//NoGradGuard guard;

// void processVideo(const std::string&  modelName, c10::Device device, const std::string&  vidName);

int main(int argc, char *argv[]) { //./../style_model_cpp.pt ./../imgs/RGB_00_001.jpg

    auto VU= VisionUtils();

    cout << "OpenCV version : " << CV_VERSION << endl;
    cout << "Major version : " << CV_MAJOR_VERSION << endl;
    cout << "Minor version : " << CV_MINOR_VERSION << endl;
    cout << "Subminor version : " << CV_SUBMINOR_VERSION << endl;

    auto videoLambda =[&](const std::string&  modelName, c10::Device device, const std::string&  vidName) {
        VU::processVideo(modelName, device, vidName);
    };

    // Loading your model
    const std::string s_model_name = argv[1];
    const std::string vid3 = argv[2];

    c10::Device device = torch::kCUDA;

    auto vid1Callback2 =std::async(std::launch::async, [&](){
        videoLambda(s_model_name, device,  vid3);
    });
    return 0;
}


// void processVideo(const std::string&  modelName, c10::Device device, const std::string&  vidName) {
//     auto VU= VisionUtils();

//     std::thread::id this_id = std::this_thread::get_id();
//     stringstream ss_id;
//     ss_id << this_id;
//     string this_id_str = ss_id.str();

//     std::cout << "thread: " << this_id <<std::endl;

//     std::cout << " >>> Loading " << modelName << std::endl;
// //    std::shared_ptr<torch::jit::script::Module> module = torch::jit::load(s_model_name);     
//     auto module = torch::jit::load(modelName, torch::kCUDA);
// //    module->to(at::kCUDA);
//     assert(module != nullptr);

//     cv::VideoCapture video_reader;
//     cv::Mat frame;
//     if (!video_reader.open(vidName)) {
//         cout << "cannot open video " << endl;
//     }
    
//     long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
//     long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
//     long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
//     cv::VideoWriter videoWriter;
// //    videoWriter.open(cv::VideoWriter::fourcc('I', 'Y', 'U', 'V'), 25, cv::Size(frame_w, frame_h));
//     cout << "WIDTH " << frame_w << "\n";
//     cout << "HEIGHT " << frame_h << "\n";
//     cout << "NB FRAMES " << nb_frames << "\n";
// //    cv::Size imageSize = cv::Size(cap.get(CV_CAP_PROP_FRAME_WIDTH), cap.get(CV_CAP_PROP_FRAME_HEIGHT));

//     for (long num_frames = 0; num_frames < nb_frames; num_frames++) {
//         video_reader >> frame;

//         auto input_tensor=VU.toTensor(frame,frame_h, frame_w, kCHANNELS);
//         torch::Tensor out_tensor = module.forward({input_tensor}).toTensor();
//         auto resultImg= VU.toOpenCV (out_tensor,frame_h, frame_w, kCHANNELS);                   

//         stringstream ss_nb;
//         ss_nb << num_frames;
//         string num_frames_str = ss_nb.str();

//         cv::putText(resultImg,
//                     this_id_str,
//                     cv::Point(50,50), // Coordinates
//                     cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
//                     2.0, // Scale. 2.0 = 2x bigger
//                     cv::Scalar(255,125,0), // BGR Color
//                     1 // Line Thickness (Optional)
//                     );

//         cv::putText(resultImg,
//                     num_frames_str,
//                     cv::Point(100,100), // Coordinates
//                     cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
//                     1.0, // Scale. 2.0 = 2x bigger
//                     cv::Scalar(255,255,0), // BGR Color
//                     1 // Line Thickness (Optional)
//         );

//         cv::imshow(this_id_str, resultImg);
//         char key = cv::waitKey(10);
//         if (key == 27) // ESC
//             break;        
//     }
// }


// cv::cvtColor(frame, frame, CV_BGR2RGB);
        // frame.convertTo(frame, CV_32FC3, 1.0f / 255.0f);
        // auto input_tensor = torch::from_blob(frame.data, {1, frame_h, frame_w, kCHANNELS});
        // input_tensor = input_tensor.permute({0, 3, 1, 2});
        // input_tensor = input_tensor.to(torch::kCUDA);
//        inputVector.emplace_back(input_tensor); // Add the frame to the vector
//        auto out_tensor = module->forward({inputVector}).toTensor(); // torch::jit::IValue // c10::IValue
        // auto out_tensor = module.forward({input_tensor}).toTensor(); // torch::jit::IValue // c10::IValue
//        cout <<typeid(out_tensor).name()<<std::endl;
        // std::cout <<"out_tensor.size():" << out_tensor.size(0)<< "/" << out_tensor.size(1)<< "/"<<out_tensor.size(2)<<"/" << out_tensor.size(3)<<std::endl;
//         out_tensor = out_tensor.squeeze().detach().permute({1, 2, 0});
//         out_tensor = out_tensor.mul(255).clamp(0, 255).to(torch::kU8);
//         out_tensor = out_tensor.to(torch::kCPU);
// //        std::cout << out_tensor.sizes() << "\n"; //[360, 480, 3]
//         cv::Mat resultImg(frame_h, frame_w, CV_8UC3);
//         memcpy((void *) resultImg.data, out_tensor.data_ptr(), sizeof(torch::kU8) * out_tensor.numel());
//              cv::imwrite("neural.jpg", resultImg);
        // std::cout << "thread: " << this_id <<std::endl;