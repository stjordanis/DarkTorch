//#include <torch/torch.h>
#include <torch/script.h> // One-stop header.

#include <iostream>
#include <vector>
#include <memory>
#include <cmath>

#include <iostream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <typeinfo>
//#include <include/neural.h>

using namespace std;
//using namespace cv;
using namespace std::chrono;

#define kIMAGE_SIZE 512
#define kCHANNELS 3
#define kTOP_K 3

//temporarily disable gradient recording
//NoGradGuard guard;

int main(int argc, char *argv[]) { //./../style_model_cpp.pt ./../imgs/RGB_00_001.jpg

    cout << "OpenCV version : " << CV_VERSION << endl;
    cout << "Major version : " << CV_MAJOR_VERSION << endl;
    cout << "Minor version : " << CV_MINOR_VERSION << endl;
    cout << "Subminor version : " << CV_SUBMINOR_VERSION << endl;

    // Loading your model
    const std::string s_model_name = argv[1];
    std::cout << " >>> Loading " << s_model_name << std::endl;
//    std::shared_ptr<torch::jit::script::Module> module = torch::jit::load(s_model_name);
    auto module = torch::jit::load(s_model_name, torch::kCUDA);
//    module->to(at::kCUDA);
    assert(module != nullptr);
//    const std::string s_image_name0 = argv[2];
//    std::cout << " >>> Loading " << s_image_name0 << std::endl;
    time_t start, end;
    long num_frames = 0;
    time(&start);

    cv::VideoCapture video_reader;
    cv::Mat frame;
    if (!video_reader.open("../data/ww2.mp4")) {
        std::cout << "cannot open video " << std::endl;
    }
    long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
    long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
    long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
    cv::VideoWriter videoWriter;
//    videoWriter.open(cv::VideoWriter::fourcc('I', 'Y', 'U', 'V'), 25, cv::Size(frame_w, frame_h));
    std::cout << "WIDTH " << frame_w << "\n";
    std::cout << "HEIGHT " << frame_h << "\n";
    std::cout << "NB FRAMES " << nb_frames << "\n";
//    cv::Size imageSize = cv::Size(cap.get(CV_CAP_PROP_FRAME_WIDTH), cap.get(CV_CAP_PROP_FRAME_HEIGHT));

    int batch_size =2;
    int b_counter=0;

    std::vector<torch::jit::IValue> inputs; //Accumulates the batches

    for (num_frames = 0; num_frames < nb_frames; num_frames++) {
        video_reader >> frame;
        cv::cvtColor(frame, frame, CV_BGR2RGB);
        frame.convertTo(frame, CV_32FC3, 1.0f / 255.0f);
        auto input_tensor = torch::from_blob(frame.data, {1, frame_h, frame_w, kCHANNELS});

        input_tensor = input_tensor.permute({0, 3, 1, 2});

        inputs.emplace_back(input_tensor.to(torch::kCUDA)); // Add the frame to the vector
//        std::cout <<"frames:" << num_frames<<std::endl;
//        std::cout <<"inputs.size():" << inputs.size()<<std::endl;

        //Ok we now have enough inputs
        if (batch_size == inputs.size()) {
            b_counter++;
            std::cout <<"Batch:" << b_counter<<std::endl;
//            std::cout <<"inputs.size() loop:" << inputs.size()<<std::endl;
            auto out_tensor = module->forward(inputs); // torch::jit::IValue // c10::IValue
//            cout <<typeid(out_tensor).name()<<std::endl;
//            std::cout <<"out_tensor.size():" << out_tensor.size(0)<< "/" << out_tensor.size(1)<< "/"<<out_tensor.size(2)<<"/" << out_tensor.size(3)<<std::endl;

//            out_tensor = out_tensor.squeeze().detach().permute({1, 2, 0});
//            out_tensor = out_tensor.mul(255).clamp(0, 255).to(torch::kU8);
//            out_tensor = out_tensor.to(torch::kCPU);
//            std::cout << out_tensor.sizes() << "\n";

//            for (int batch_index = 0; batch_index < batch_size; batch_index++) {
//
//                cv::Mat resultImg(frame_h, frame_w, CV_8UC3);
////                std::memcpy((void *) resultImg.data, out_tensor[0].data_ptr(), sizeof(torch::kU8) * out_tensor[0].numel());
//                std::memcpy((void *) resultImg.data, out_tensor.data_ptr(), sizeof(torch::kU8) * out_tensor.numel());
////              cv::imwrite("neural.jpg", resultImg);
//                cv::imshow("Vid", resultImg);
//                cv::waitKey(1);
//            }

            inputs.clear();
        }

        time(&end);
        // Time elapsed
        double seconds = difftime(end, start);
//        cout << "Time taken : " << MILL << " seconds" << endl;
        // Calculate frames per second
//        double fps = num_frames / seconds;
//        cout << "Estimated frames per second : " << fps << endl;

    }

    std::cout <<"inputs.size() LEFT:" << inputs.size()<<std::endl;
    return 0;
}





//    cv::Mat result;
//    cv::namedWindow("My Image");
//    cv::imshow("My Image", img1);
//    cv::waitKey(0);

//blur image
//    cv::blur(img1, result, cv::Size(5, 5));
//    cv::imshow("My Image", result);
//    cv::waitKey(0);

//    for (num_frames  =0;num_frames <1000;num_frames ++) {
//        std::vector<torch::jit::IValue> inputs;
//        inputs.emplace_back(torch::rand({4, 3, 512, 512}).to(torch::kCUDA));
//        auto t = (double) cv::getTickCount();
//        module->forward(inputs).toTensor();
//        t = (double) cv::getTickCount() - t;
//        printf("Execution time = %gs\n", t / cv::getTickFrequency());
//        inputs.pop_back();
//    }