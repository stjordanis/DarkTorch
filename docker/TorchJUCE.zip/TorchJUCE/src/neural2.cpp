//#include <torch/torch.h>
#include <torch/script.h> // One-stop header.

#include <iostream>
#include <vector>
#include <memory>
#include <cmath>

#include <iostream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <ostream>

#include "../include/termcolor/termcolor.hpp"
#include "../include/tqdm/tqdm.h"
//#include <include/termcolor/termcolor.hpp>

#include "torch/torch.h"


using namespace std;
//using namespace cv;
using namespace std::chrono;

#define kIMAGE_SIZE 512
#define kIMAGE_SIZE_TORCH 512
#define kCHANNELS 3
#define kTOP_K 3

int main(int argc, char *argv[]) { //./../res34_model_cpp.pt ./../imgs/RGB_00_001.jpg

    // std::cout << termcolor::reset << std::endl;
    torch::jit::getProfilingMode() = false;
    torch::jit::getExecutorMode() = false;
    torch::jit::setGraphExecutorOptimize(false);

    cout << "OpenCV version : " << CV_VERSION << endl;
    cout << "Major version : " << CV_MAJOR_VERSION << endl;
    cout << "Minor version : " << CV_MINOR_VERSION << endl;
    cout << "Subminor version : " << CV_SUBMINOR_VERSION << endl;
    // std::cout << termcolor::reset << std::endl;

    // Loading your model
    const std::string s_model_name = argv[1];
    std::cout << termcolor::bold << termcolor::blink << "Loading " << s_model_name << std::endl;
//    std::shared_ptr<torch::jit::script::Module> module = torch::jit::load(s_model_name);
    auto module = torch::jit::load(s_model_name, torch::kCUDA);
//    module->to(at::kCUDA);
    assert(module != nullptr);

    const std::string s_image_name0 = argv[2];
    std::cout << " >>> Loading " << s_image_name0 << std::endl;

    time_t start, end;
    long num_frames = 0;
    time(&start);

    
    cv::VideoCapture video_reader(s_image_name0);    
    if (!video_reader.isOpened())
    {
        std::cout << "!!! Failed to open file: " << s_image_name0 << std::endl;
        return -1;
    }

    long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
    long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
    long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
    cv::VideoWriter videoWriter;

    std::cout << "WIDTH " << frame_w << "\n";
    std::cout << "HEIGHT " << frame_h << "\n";
    std::cout << "nb_frames " << nb_frames << "\n";

    double avgFPS = 1.0;
    cv::Mat frame;    
    tqdm bar;
    bar.reset();
//    bar.set_theme_basic();
    bar.set_theme_circle();    


    for (num_frames = 0; num_frames < nb_frames; num_frames++) {
        clock_t start = clock();

        video_reader.read(frame);        
        // video_reader >> frame;
        cv::cvtColor(frame, frame, CV_BGR2RGB);        
        //#frame = cv2.resize(frame, (224, 224));
        frame.convertTo(frame, CV_32FC3, 1.0f / 255.0f);     
           
        cv::resize(frame, frame, cv::Size(kIMAGE_SIZE_TORCH, kIMAGE_SIZE_TORCH));
        
        auto input_tensor = torch::from_blob(frame.data, {1, kIMAGE_SIZE_TORCH, kIMAGE_SIZE_TORCH, kCHANNELS});
        
        // input_tensor = input_tensor.permute({0, 3, 1, 2});
        // input_tensor = input_tensor.to(at::kCUDA);        
        
        // torch::Tensor out_tensor = module.forward({input_tensor}).toTensor();
       

        // out_tensor = out_tensor.squeeze().detach().permute({1, 2, 0});
        // out_tensor = out_tensor.mul(255).clamp(0, 255).to(torch::kU8);
        // out_tensor = out_tensor.to(torch::kCPU);
        // cv::Mat resultImg(kIMAGE_SIZE_TORCH, kIMAGE_SIZE_TORCH, CV_8UC3);
        // std::memcpy((void *) resultImg.data, out_tensor.data_ptr(), sizeof(torch::kU8) * out_tensor.numel());


        // cv::imshow("window", resultImg);
        // char key = cv::waitKey(10);
        // if (key == 27) // ESC
        //     break;

        // std::cout << "frame " << out_tensor << "\n";
        bar.progress(num_frames, nb_frames);
    }

    bar.finish();
    time(&end);
    // Time elapsed
    double seconds = difftime(end, start);
    cout << "Time taken : " << seconds << " seconds" << endl;
    // Calculate frames per second
    double fps = num_frames / seconds;
    cout << "Estimated frames per second : " << fps << endl;

    return 0;
}
