import torch
import torchvision
import re
import torch
import os
import random

# from models.neural import *

# style_model = TransformerNet()
# state_dict = torch.load("models/weights/neural/mosaic.pth")
# for k in list(state_dict.keys()):
#     if re.search(r'in\d+\.running_(mean|var)$', k):
#         del state_dict[k]
# style_model.load_state_dict(state_dict)
# style_model.eval()
        
# # model = torchvision.models.resnet50(pretrained=True)
# # model.eval()
# example = torch.rand(1, 3, 224, 224)
# traced_script_module = torch.jit.trace(style_model, example)
# traced_script_module.save("style_model_cpp.pt")

import torch
import numpy as np
from PIL import Image
from torchvision import transforms
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection import maskrcnn_resnet50_fpn

device = torch.device('cuda:0')
# device = torch.device('cpu')

# model = fasterrcnn_resnet50_fpn(pretrained=True)
model = torchvision.models.detection.maskrcnn_resnet50_fpn(pretrained=True)

im = Image.open('imgs/RGB_00_000.jpg')
transform = transforms.Compose([
    transforms.Resize((500, 667)),
    transforms.ToTensor(),])
im_input = transform(im).unsqueeze(0)
model.to(device).eval()
predictions = model(im_input.to(device))

traced_model = torch.jit.script(model)
print(transform(im).shape)
torch.jit.save(traced_model, 'rcnn_gpu.pt')