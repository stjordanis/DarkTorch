#include <iostream>
#include <chrono>

#include <opencv2/core/core.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgproc/types_c.h>
#include <iostream>
#include <time.h>
#include <typeinfo>
//#include <include/neural.h>
#include <thread>
#include <future>

using namespace std;
//using namespace cv;
using namespace std::chrono;

// #include "JuceHeader.h"


class VisionUtils{
public:
  enum mode_convert{
    CONVERT_COLOR,
    CONVERT_GRAYSCALE
  };
  VisionUtils();
  at::Tensor toTensor(cv::Mat image,int h, int w, int c);  
  cv::Mat toOpenCV(at::Tensor out_tensor, int h, int w, int c);
  void processVideo(const std::string&  modelName, c10::Device device, const std::string&  vidName);
  juce::Image toJUCEImage(cv::Mat original,int h, int w, int c);
};

VisionUtils::VisionUtils(){}

at::Tensor VisionUtils::toTensor(cv::Mat frame, int h, int w, int c)
{ 

  cv::cvtColor(frame, frame, CV_BGR2RGB);
  frame.convertTo(frame, CV_32FC3, 1.0f / 255.0f);
  auto input_tensor = torch::from_blob(frame.data, {1, h, w, c});
  input_tensor = input_tensor.permute({0, 3, 1, 2});
  input_tensor = input_tensor.to(torch::kCUDA);  
  return input_tensor;
}

cv::Mat VisionUtils::toOpenCV(at::Tensor out_tensor, int h, int w, int c)
{     
  out_tensor = out_tensor.squeeze().detach().permute({1, 2, 0});
  out_tensor = out_tensor.mul(255).clamp(0, 255).to(torch::kU8);
  out_tensor = out_tensor.to(torch::kCPU);  
  cv::Mat resultImg(h, w, CV_8UC3);
  // cv::Mat resultImg(h, w, CV_8UC1);  
  std::memcpy((void *) resultImg.data, out_tensor.data_ptr(), sizeof(torch::kU8) * out_tensor.numel());
  return resultImg;
}


void VisionUtils::processVideo(const std::string&  modelName, c10::Device device, const std::string&  vidName) {    
    int kCHANNELS=3;

    std::thread::id this_id = std::this_thread::get_id();
    stringstream ss_id;
    ss_id << this_id;
    string this_id_str = ss_id.str();

    std::cout << "thread: " << this_id <<std::endl;

    std::cout << " >>> Loading " << modelName << std::endl;
//    std::shared_ptr<torch::jit::script::Module> module = torch::jit::load(s_model_name);     
    auto module = torch::jit::load(modelName, torch::kCUDA);
//    module->to(at::kCUDA);
    assert(module != nullptr);

    cv::VideoCapture video_reader;
    cv::Mat frame;
    if (!video_reader.open(vidName)) {
        cout << "cannot open video " << endl;
    }
    
    long frame_h = int(video_reader.get(cv::CAP_PROP_FRAME_HEIGHT));
    long frame_w = int(video_reader.get(cv::CAP_PROP_FRAME_WIDTH));
    long nb_frames = int(video_reader.get(cv::CAP_PROP_FRAME_COUNT));
    cv::VideoWriter videoWriter;
//    videoWriter.open(cv::VideoWriter::fourcc('I', 'Y', 'U', 'V'), 25, cv::Size(frame_w, frame_h));
    cout << "WIDTH " << frame_w << "\n";
    cout << "HEIGHT " << frame_h << "\n";
    cout << "NB FRAMES " << nb_frames << "\n";
//    cv::Size imageSize = cv::Size(cap.get(CV_CAP_PROP_FRAME_WIDTH), cap.get(CV_CAP_PROP_FRAME_HEIGHT));

    for (long num_frames = 0; num_frames < nb_frames; num_frames++) {
        video_reader >> frame;

        auto input_tensor=toTensor(frame,frame_h, frame_w, kCHANNELS);
        torch::Tensor out_tensor = module.forward({input_tensor}).toTensor();
        auto resultImg= toOpenCV (out_tensor,frame_h, frame_w, kCHANNELS);                   

        stringstream ss_nb;
        ss_nb << num_frames;
        string num_frames_str = ss_nb.str();

        cv::putText(resultImg,
                    this_id_str,
                    cv::Point(50,50), // Coordinates
                    cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
                    2.0, // Scale. 2.0 = 2x bigger
                    cv::Scalar(255,125,0), // BGR Color
                    1 // Line Thickness (Optional)
                    );

        cv::putText(resultImg,
                    num_frames_str,
                    cv::Point(100,100), // Coordinates
                    cv::FONT_HERSHEY_COMPLEX_SMALL, // Font
                    1.0, // Scale. 2.0 = 2x bigger
                    cv::Scalar(255,255,0), // BGR Color
                    1 // Line Thickness (Optional)
        );

        cv::imshow(this_id_str, resultImg);
        char key = cv::waitKey(10);
        if (key == 27) // ESC
            break;        
    }
}

juce::Image VisionUtils::toJUCEImage(cv::Mat original,int h, int w, int c)
{
	// create a JUCE Image the exact same size as the OpenCV mat we're using as our source
	juce::Image image(juce::Image::RGB, h, w, false);

	// iterate through each row of the image, copying the entire row as a series of consecutive bytes
	const size_t number_of_bytes_to_copy = 3 * w; // times 3 since each pixel contains 3 bytes (RGB)
	juce::Image::BitmapData bitmap_data(image, 0, 0, h,w, juce::Image::BitmapData::ReadWriteMode::writeOnly);
	for (int row_index = 0; row_index < h; row_index ++)
	{
		uint8_t * src_ptr = original.ptr(row_index);
		uint8_t * dst_ptr = bitmap_data.getLinePointer(row_index);

		std::memcpy(dst_ptr, src_ptr, number_of_bytes_to_copy);
	}

	return image;
}


// /*! Converts a tensor to an image
// * Addtitional control is given over the number of channels. It requires to know the resulting image size.
// */

// cv::Mat TConverter::toImage(at::Tensor& tensor, TConverter::mode_convert mode, cv::Size sizes)
// {
//   cv::Mat image;
//   if(mode == TConverter::CONVERT_COLOR){
//     image = cv::Mat(sizes, CV_8UC3, tensor.data_ptr()); 
//   }
//   else if(mode == TConverter::CONVERT_GRAYSCALE){
//     image = cv::Mat(sizes, CV_8UC1, tensor.data_ptr()); 
//   }
//   return image;
// }

